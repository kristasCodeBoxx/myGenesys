Version: 1.5.4 Licensed plugin 
Do not update this plugin!